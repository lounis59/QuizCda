<template>
<div class="home">
        <Login/>
</div>

</template>

<script setup>
import Login from '@/components/Login.vue';
</script>

<style lang="scss">

</style>