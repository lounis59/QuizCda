<template>
<div class="home">
    <div class="Btn" @click="selectTheme" v-if="!theme">Choisir un theme</div>
    <div class="Btn" @click="removeTheme" v-if="theme">Retour</div>
    <div v-if="theme">

        <div class="Btn" v-for="index in theme" :key="index">{{ index}}</div>
    </div>
</div>

</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';


const route = useRouter();
const theme = ref('')

const selectTheme = () => 
{
    
        fetch('data/question.json')
        .then(response => response.json())
        .then(data => theme.value = data.theme)
        .catch(error => console.error('erreur lors du chargement du JSON:', error));
        
        
    
    console.log('ici' ,theme);
}
const removeTheme = () => {
    theme.value = ''
}

</script>

<style lang="scss" >

</style>